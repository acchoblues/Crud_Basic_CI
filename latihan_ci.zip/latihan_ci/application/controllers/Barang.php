<?php

class Barang extends CI_Controller{
    
    function index(){
        $this->load->model('Model_barang');
        $judul = "Daftar Barang";
        $data['judul'] = $judul;
        $data['barang'] = $this->Model_barang->list_barang()->result();
        $this->load->view('list_barang',$data);
    }
    
    function input(){
        
        $this->load->view('input_barang');
    }
    
    function input_simpan(){
        //$kode = $this->input->post('kode_barang');
        //echo $kode;
        $databarang = array(
        'kode_barang' => $this->input->post('kode_barang'),
        'nama_barang' => $this->input->post('nama_barang'),
        'harga' => $this->input->post('harga')
        );
        $this->db->insert('barang',$databarang);    
        redirect('Barang');
    }
    
    function edit(){
       //echo "Hakko Bio Richard";
       $this->load->model('model_barang');
       $kode_barang = $this->uri->segment(3);
       $data['product'] = $this->model_barang->product($kode_barang)->row_array();
       $this->load->view('edit_barang',$data);
       
    }
    
    function delete(){
        $kode_barang = $this->uri->segment(3);
        $this->db->where('kode_barang',$kode_barang);
        $this->db->delete('barang',$databarang);
        redirect('Barang');
        
    }
    
}