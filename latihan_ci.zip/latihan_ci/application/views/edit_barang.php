<?php echo form_open('barang/edit_simpan'); ?>
<table>
<tr><td>Kode Barang</td><td><?php echo form_input('kode_barang',$product['kode_barang'],array('placeholder'=>'Kode Barang')); ?></td></tr>
<tr><td>Nama Barang</td><td><?php echo form_input('nama_barang',$product['nama_barang'],array('placeholder'=>'Nama Barang')); ?></td></tr>
<tr><td>Harga Barang</td><td><?php echo form_input('harga',$product['harga'],array('placeholder'=>'Harga Barang')); ?></td></tr>
<tr><td colspan="2"><?php echo form_submit('Submit','Simpan Data') ?> <?php echo anchor('barang','Kembali'); ?></td></tr>
</table>
<?php echo form_close(); ?>